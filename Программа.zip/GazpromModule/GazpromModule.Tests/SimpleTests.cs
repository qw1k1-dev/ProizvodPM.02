﻿using System;
using Xunit;

namespace GazpromModule.Tests
{
    public class SimpleTests
    {
        [Fact]
        public void Test_Addition_ShouldPass()
        {
            // Arrange
            int a = 5;
            int b = 10;

            // Act
            int result = a + b;

            // Assert
            Assert.Equal(15, result);
        }

        [Fact]
        public void Test_String_ShouldPass()
        {
            // Arrange
            string name = "Газпром";

            // Act
            string upper = name.ToUpper();

            // Assert
            Assert.Equal("ГАЗПРОМ", upper);
        }

        [Theory]
        [InlineData(2, 3, 5)]
        [InlineData(10, 20, 30)]
        [InlineData(-5, 5, 0)]
        public void Test_MultipleAdditions_ShouldPass(int a, int b, int expected)
        {
            // Act
            int result = a + b;

            // Assert
            Assert.Equal(expected, result);
        }

        [Fact]
        public void Test_Exception_ShouldThrow()
        {
            // Assert
            Assert.Throws<DivideByZeroException>(() =>
            {
                int x = 10;
                int y = 0;
                int result = x / y;
            });
        }

        [Fact]
        public void Test_List_ShouldContainItem()
        {
            // Arrange
            var list = new List<string> { "У-101", "У-102", "У-103" };

            // Act & Assert
            Assert.Contains("У-102", list);
            Assert.Equal(3, list.Count);
        }
    }
}