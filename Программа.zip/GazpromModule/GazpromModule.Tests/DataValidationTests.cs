﻿using System;
using System.Globalization;
using Xunit;

namespace GazpromModule.Tests
{
    public class DataValidationTests
    {
        [Fact]
        public void Test_DateRange_ShouldBeValid()
        {
            // Arrange
            var startDate = new DateTime(2025, 1, 1);
            var endDate = new DateTime(2025, 1, 31);

            // Act
            bool isValid = startDate < endDate;

            // Assert
            Assert.True(isValid);
        }

        [Fact]
        public void Test_CurrencyFormat_ShouldBeCorrect()
        {
            // Arrange
            decimal price = 4500.50m;
            string currency = "RUB";

            // Act
            // Используем инвариантную культуру для предсказуемого результата
            string formatted = price.ToString("N2", CultureInfo.InvariantCulture) + " " + currency;

            // Assert
            // В инвариантной культуре: 4,500.50 RUB
            Assert.Equal("4,500.50 RUB", formatted);
        }

        [Fact]
        public void Test_CurrencyFormat_RussianCulture()
        {
            // Arrange
            decimal price = 4500.50m;
            string currency = "RUB";
            var russianCulture = new CultureInfo("ru-RU");

            // Act
            string formatted = price.ToString("N2", russianCulture) + " " + currency;

            // Assert
            // В русской культуре: 4 500,50 RUB
            // Не используем точное сравнение из-за разных типов пробелов
            Assert.Contains("4", formatted);
            Assert.Contains("500", formatted);
            Assert.Contains("50", formatted);
            Assert.Contains("RUB", formatted);
        }

        [Fact]
        public void Test_GasVolumeValidation_ShouldWork()
        {
            // Arrange
            decimal validVolume = 150;
            decimal invalidVolume = -10;

            // Act
            bool isValidVolume = validVolume >= 0;
            bool isInvalidVolume = invalidVolume >= 0;

            // Assert
            Assert.True(isValidVolume);
            Assert.False(isInvalidVolume);
        }

        [Fact]
        public void Test_PriceCalculation_ShouldBeCorrect()
        {
            // Arrange
            decimal gasVolume = 1000;
            decimal pricePer1000m3 = 4500.50m;

            // Act
            decimal revenue = gasVolume * pricePer1000m3;

            // Assert
            Assert.Equal(4500500m, revenue);
        }

        [Fact]
        public void Test_WellNumber_ShouldNotBeEmpty()
        {
            // Arrange
            string wellNumber = "У-101";

            // Act
            bool isValid = !string.IsNullOrWhiteSpace(wellNumber);

            // Assert
            Assert.True(isValid);
        }
    }
}