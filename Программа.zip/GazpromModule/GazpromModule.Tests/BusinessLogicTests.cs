﻿using System;
using System.Collections.Generic;
using Xunit;

namespace GazpromModule.Tests
{
    public class BusinessLogicTests
    {
        // Тест расчета выручки
        [Fact]
        public void CalculateRevenue_ValidData_ShouldCalculateCorrectly()
        {
            // Arrange
            decimal gasVolume = 1000;
            decimal pricePer1000m3 = 5000;

            // Act
            decimal revenue = gasVolume * pricePer1000m3;

            // Assert
            Assert.Equal(5000000, revenue);
        }

        // Тест валидации номера скважины
        [Theory]
        [InlineData("У-101", true)]
        [InlineData("Я-201", true)]
        [InlineData("", false)]
        [InlineData(null, false)]
        [InlineData("   ", false)]
        public void ValidateWellNumber_ShouldValidateCorrectly(string wellNumber, bool expected)
        {
            // Act
            bool isValid = !string.IsNullOrWhiteSpace(wellNumber);

            // Assert
            Assert.Equal(expected, isValid);
        }

        // Тест валидации глубины
        [Theory]
        [InlineData(3000, true)]
        [InlineData(100, true)]
        [InlineData(0, false)]
        [InlineData(-100, false)]
        public void ValidateDepth_ShouldValidateCorrectly(decimal depth, bool expected)
        {
            // Act
            bool isValid = depth > 0;

            // Assert
            Assert.Equal(expected, isValid);
        }

        // Тест валидации пароля
        [Theory]
        [InlineData("password123", true)]
        [InlineData("123", false)]
        [InlineData("", false)]
        [InlineData(null, false)]
        public void ValidatePassword_ShouldValidateCorrectly(string password, bool expected)
        {
            // Act
            bool isValid = !string.IsNullOrEmpty(password) && password.Length >= 6;

            // Assert
            Assert.Equal(expected, isValid);
        }

        // Тест расчета среднего объема
        [Fact]
        public void CalculateAverageVolume_ShouldCalculateCorrectly()
        {
            // Arrange
            var measurements = new List<decimal> { 100, 150, 200, 250, 300 };

            // Act
            decimal total = 0;
            foreach (var m in measurements)
            {
                total += m;
            }
            decimal average = total / measurements.Count;

            // Assert
            Assert.Equal(200, average);
        }

        // Тест определения статуса скважины
        [Theory]
        [InlineData("действующая", true)]
        [InlineData("законсервированная", false)]
        [InlineData("ликвидированная", false)]
        public void IsActiveWell_ShouldReturnCorrectStatus(string status, bool expected)
        {
            // Act
            bool isActive = status == "действующая";

            // Assert
            Assert.Equal(expected, isActive);
        }

        // Тест формата номера скважины
        [Fact]
        public void Test_WellNumberFormat_ShouldMatchPattern()
        {
            // Arrange
            string wellNumber = "У-101";

            // Act
            bool matchesPattern = System.Text.RegularExpressions.Regex.IsMatch(wellNumber, @"^[А-Я]-\d{3}$");

            // Assert
            Assert.True(matchesPattern);
        }
    }
}