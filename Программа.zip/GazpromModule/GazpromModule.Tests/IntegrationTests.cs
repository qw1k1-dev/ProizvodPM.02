﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace GazpromModule.Tests
{
    public class IntegrationTests
    {
        [Fact]
        public void FullWorkflow_CreateWellAndAddMeasurement_ShouldWork()
        {
            // Arrange
            var wells = new List<Well>();
            var measurements = new List<Measurement>();

            // Создаем скважину
            var well = new Well
            {
                Id = 1,
                WellNumber = "У-101",
                FieldName = "Уренгойское",
                Depth = 3200.50m,
                Status = "действующая"
            };
            wells.Add(well);

            // Добавляем замер
            var measurement = new Measurement
            {
                Id = 1,
                WellId = well.Id,
                MeasurementDate = DateTime.Now,
                GasVolume = 150.5m,
                Pressure = 70.2m,
                Temperature = 40.1m,
                OperatorName = "Иванов И.И."
            };
            measurements.Add(measurement);

            // Act - Проверяем, что скважина и замер связаны
            var wellMeasurements = measurements.Where(m => m.WellId == well.Id).ToList();

            // Assert
            Assert.Single(wells);
            Assert.Single(measurements);
            Assert.Single(wellMeasurements);
            Assert.Equal(well.Id, measurement.WellId);
            Assert.Equal(150.5m, measurement.GasVolume);
        }

        [Fact]
        public void IntegrationTest_WellMaintenanceWorkflow()
        {
            // Arrange
            var wells = new List<Well>();
            var maintenances = new List<Maintenance>();

            // Создаем скважину
            var well = new Well
            {
                Id = 1,
                WellNumber = "У-102",
                FieldName = "Ямбургское",
                Status = "действующая"
            };
            wells.Add(well);

            // Добавляем обслуживание
            var maintenance = new Maintenance
            {
                Id = 1,
                WellId = well.Id,
                WorkType = "Плановый ремонт",
                StartDate = DateTime.Now.AddDays(-10),
                EndDate = DateTime.Now.AddDays(-8),
                Description = "Замена клапанов",
                ResponsiblePerson = "Петров П.П.",
                Result = "Успешно завершено"
            };
            maintenances.Add(maintenance);

            // Act - Проверяем связь
            var wellMaintenances = maintenances.Where(m => m.WellId == well.Id).ToList();

            // Assert
            Assert.Single(wellMaintenances);
            Assert.Equal("Плановый ремонт", maintenance.WorkType);
            Assert.Equal("Успешно завершено", maintenance.Result);
        }

        [Fact]
        public void IntegrationTest_UserAuthenticationFlow()
        {
            // Arrange
            var users = new List<User>();

            var user = new User
            {
                Id = 1,
                Username = "admin",
                PasswordHash = "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9",
                FullName = "Администратор",
                Role = "Администратор",
                IsActive = true
            };
            users.Add(user);

            // Act - Проверяем аутентификацию
            var foundUser = users.FirstOrDefault(u => u.Username == "admin" && u.IsActive);

            // Assert
            Assert.NotNull(foundUser);
            Assert.Equal("Администратор", foundUser.Role);
        }

        [Fact]
        public void IntegrationTest_GasPriceCalculation()
        {
            // Arrange
            var gasPrices = new List<GasPrice>();
            var measurements = new List<Measurement>();

            // Добавляем цену
            gasPrices.Add(new GasPrice
            {
                Id = 1,
                PriceDate = DateTime.Today,
                PricePer1000m3 = 5000m,
                Currency = "RUB"
            });

            // Добавляем замер
            measurements.Add(new Measurement
            {
                Id = 1,
                WellId = 1,
                MeasurementDate = DateTime.Today,
                GasVolume = 100m
            });

            // Act - Рассчитываем выручку
            var price = gasPrices.First();
            var totalVolume = measurements.Sum(m => m.GasVolume);
            var revenue = totalVolume * price.PricePer1000m3;

            // Assert
            Assert.Equal(500000m, revenue);
        }

        [Fact]
        public void IntegrationTest_CompleteWorkflow()
        {
            // Arrange - Создаем все данные
            var user = new User { Id = 1, Username = "engineer", Role = "Инженер" };
            var well = new Well { Id = 1, WellNumber = "У-103", Status = "действующая" };
            var measurement = new Measurement
            {
                Id = 1,
                WellId = well.Id,
                GasVolume = 200m,
                MeasurementDate = DateTime.Now
            };
            var maintenance = new Maintenance
            {
                Id = 1,
                WellId = well.Id,
                WorkType = "Профилактика",
                StartDate = DateTime.Now
            };

            // Act - Проверяем все связи
            bool userIsValid = !string.IsNullOrEmpty(user.Username) && !string.IsNullOrEmpty(user.Role);
            bool wellIsValid = !string.IsNullOrEmpty(well.WellNumber) && well.Status == "действующая";
            bool measurementIsValid = measurement.GasVolume >= 0 && measurement.WellId == well.Id;
            bool maintenanceIsValid = maintenance.WellId == well.Id && !string.IsNullOrEmpty(maintenance.WorkType);

            // Assert
            Assert.True(userIsValid);
            Assert.True(wellIsValid);
            Assert.True(measurementIsValid);
            Assert.True(maintenanceIsValid);
        }

        [Fact]
        public void IntegrationTest_DataConsistency()
        {
            // Arrange
            var wells = new List<Well>
            {
                new Well { Id = 1, WellNumber = "У-101" },
                new Well { Id = 2, WellNumber = "У-102" },
                new Well { Id = 3, WellNumber = "У-103" }
            };

            var measurements = new List<Measurement>
            {
                new Measurement { Id = 1, WellId = 1, GasVolume = 100 },
                new Measurement { Id = 2, WellId = 1, GasVolume = 150 },
                new Measurement { Id = 3, WellId = 2, GasVolume = 200 }
            };

            // Act - Проверяем, что все замеры привязаны к существующим скважинам
            var invalidMeasurements = measurements.Where(m => !wells.Any(w => w.Id == m.WellId)).ToList();

            // Assert
            Assert.Empty(invalidMeasurements);
            Assert.Equal(3, wells.Count);
            Assert.Equal(3, measurements.Count);
        }
    }

    // Тестовые модели
    public class Well
    {
        public int Id { get; set; }
        public string WellNumber { get; set; }
        public string FieldName { get; set; }
        public decimal Depth { get; set; }
        public string Status { get; set; }
    }

    public class Measurement
    {
        public int Id { get; set; }
        public int WellId { get; set; }
        public DateTime MeasurementDate { get; set; }
        public decimal GasVolume { get; set; }
        public decimal Pressure { get; set; }
        public decimal Temperature { get; set; }
        public string OperatorName { get; set; }
    }

    public class Maintenance
    {
        public int Id { get; set; }
        public int WellId { get; set; }
        public string WorkType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public string ResponsiblePerson { get; set; }
        public string Result { get; set; }
    }

    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
    }

    public class GasPrice
    {
        public int Id { get; set; }
        public DateTime PriceDate { get; set; }
        public decimal PricePer1000m3 { get; set; }
        public string Currency { get; set; }
    }
}