﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;

namespace GazpromModule.ViewModels
{
    public class AddMaintenanceViewModel : BaseViewModel
    {
        private readonly DataService _dataService;
        private readonly Well _well;

        private string _workType;
        private DateTime? _startDate;
        private DateTime? _endDate;
        private string _description;
        private string _responsiblePerson;
        private string _result;
        private string _errorMessage;

        public string WellNumber => _well?.WellNumber ?? "";

        public string WorkType
        {
            get => _workType;
            set => SetProperty(ref _workType, value);
        }

        public DateTime? StartDate
        {
            get => _startDate;
            set => SetProperty(ref _startDate, value);
        }

        public DateTime? EndDate
        {
            get => _endDate;
            set => SetProperty(ref _endDate, value);
        }

        public string Description
        {
            get => _description;
            set => SetProperty(ref _description, value);
        }

        public string ResponsiblePerson
        {
            get => _responsiblePerson;
            set => SetProperty(ref _responsiblePerson, value);
        }

        public string Result
        {
            get => _result;
            set => SetProperty(ref _result, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public ICommand SaveCommand { get; }

        public event EventHandler MaintenanceAdded;

        public AddMaintenanceViewModel(DataService dataService, Well well)
        {
            _dataService = dataService;
            _well = well;

            // Устанавливаем значения по умолчанию
            WorkType = "Плановый ремонт";
            StartDate = DateTime.Now;
            EndDate = DateTime.Now;

            SaveCommand = new RelayCommand(async () => await SaveAsync());
        }

        private async Task SaveAsync()
        {
            try
            {
                // Валидация
                if (string.IsNullOrWhiteSpace(WorkType))
                {
                    ErrorMessage = "Выберите тип работ";
                    return;
                }

                if (!StartDate.HasValue)
                {
                    ErrorMessage = "Укажите дату начала работ";
                    return;
                }

                if (EndDate.HasValue && StartDate.HasValue && EndDate.Value < StartDate.Value)
                {
                    ErrorMessage = "Дата окончания не может быть раньше даты начала";
                    return;
                }

                var maintenance = new Maintenance
                {
                    WellID = _well.WellID,
                    WorkType = WorkType,
                    StartDate = StartDate,
                    EndDate = EndDate,
                    Description = Description,
                    ResponsiblePerson = ResponsiblePerson,
                    Result = Result
                };

                await _dataService.AddMaintenanceAsync(maintenance);

                // Вызываем событие об успешном добавлении
                MaintenanceAdded?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка сохранения: {ex.Message}";
            }
        }
    }
}