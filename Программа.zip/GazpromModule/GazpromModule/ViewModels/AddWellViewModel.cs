﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;

namespace GazpromModule.ViewModels
{
    public class AddWellViewModel : BaseViewModel
    {
        private readonly DataService _dataService;

        private string _wellNumber;
        private ObservableCollection<Field> _fields;
        private Field _selectedField;
        private string _wellType;
        private string _depth;
        private string _status;
        private DateTime? _commissioningDate;
        private string _errorMessage;

        public string WellNumber
        {
            get => _wellNumber;
            set => SetProperty(ref _wellNumber, value);
        }

        public ObservableCollection<Field> Fields
        {
            get => _fields;
            set => SetProperty(ref _fields, value);
        }

        public Field SelectedField
        {
            get => _selectedField;
            set => SetProperty(ref _selectedField, value);
        }

        public string WellType
        {
            get => _wellType;
            set => SetProperty(ref _wellType, value);
        }

        public string Depth
        {
            get => _depth;
            set => SetProperty(ref _depth, value);
        }

        public string Status
        {
            get => _status;
            set => SetProperty(ref _status, value);
        }

        public DateTime? CommissioningDate
        {
            get => _commissioningDate;
            set => SetProperty(ref _commissioningDate, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public ICommand SaveCommand { get; }

        public event EventHandler WellAdded;

        public AddWellViewModel(DataService dataService)
        {
            _dataService = dataService;

            // Устанавливаем значения по умолчанию
            WellType = "эксплуатационная";
            Status = "действующая";
            CommissioningDate = DateTime.Now;

            SaveCommand = new RelayCommand(async () => await SaveAsync());

            // Загружаем список месторождений
            LoadFields();
        }

        private async void LoadFields()
        {
            try
            {
                var fields = await _dataService.GetFieldsAsync();
                Fields = new ObservableCollection<Field>(fields);
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка загрузки месторождений: {ex.Message}";
            }
        }

        private async Task SaveAsync()
        {
            try
            {
                // Валидация
                if (string.IsNullOrWhiteSpace(WellNumber))
                {
                    ErrorMessage = "Введите номер скважины";
                    return;
                }

                if (SelectedField == null)
                {
                    ErrorMessage = "Выберите месторождение";
                    return;
                }

                if (!decimal.TryParse(Depth, out decimal depthValue) || depthValue <= 0)
                {
                    ErrorMessage = "Введите корректную глубину (положительное число)";
                    return;
                }

                var well = new Well
                {
                    WellNumber = WellNumber.Trim(),
                    FieldID = SelectedField.FieldID,
                    WellType = WellType ?? "эксплуатационная",
                    Depth = depthValue,
                    Status = Status ?? "действующая",
                    CommissioningDate = CommissioningDate ?? DateTime.Now
                };

                await _dataService.AddWellAsync(well);

                // Вызываем событие об успешном добавлении
                WellAdded?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка сохранения: {ex.Message}";
            }
        }
    }
}