﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;

namespace GazpromModule.ViewModels
{
    public class ApiViewModel : BaseViewModel
    {
        private readonly ApiService _apiService;
        private readonly GasPriceService _gasPriceService;
        private readonly DataService _dataService;
        private readonly DialogService _dialogService;

        private GasPrice _currentPrice;
        private ObservableCollection<GasPrice> _prices;
        private string _statusMessage;
        private bool _isLoading;
        private decimal _exchangeRate;

        public GasPrice CurrentPrice
        {
            get => _currentPrice;
            set => SetProperty(ref _currentPrice, value);
        }

        public ObservableCollection<GasPrice> Prices
        {
            get => _prices;
            set => SetProperty(ref _prices, value);
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set => SetProperty(ref _statusMessage, value);
        }

        public bool IsLoading
        {
            get => _isLoading;
            set => SetProperty(ref _isLoading, value);
        }

        public decimal ExchangeRate
        {
            get => _exchangeRate;
            set => SetProperty(ref _exchangeRate, value);
        }

        public ICommand LoadPriceCommand { get; }
        public ICommand LoadPricesCommand { get; }
        public ICommand UpdatePricesCommand { get; }
        public ICommand LoadExchangeRateCommand { get; }
        public ICommand CalculateRevenueCommand { get; }

        public ApiViewModel(ApiService apiService, GasPriceService gasPriceService,
                           DataService dataService, DialogService dialogService)
        {
            _apiService = apiService;
            _gasPriceService = gasPriceService;
            _dataService = dataService;
            _dialogService = dialogService;

            Prices = new ObservableCollection<GasPrice>();

            LoadPriceCommand = new RelayCommand(async () => await LoadPriceAsync(), () => !IsLoading);
            LoadPricesCommand = new RelayCommand(async () => await LoadPricesAsync(), () => !IsLoading);
            UpdatePricesCommand = new RelayCommand(async () => await UpdatePricesAsync(), () => !IsLoading);
            LoadExchangeRateCommand = new RelayCommand(async () => await LoadExchangeRateAsync(), () => !IsLoading);
            CalculateRevenueCommand = new RelayCommand(async () => await CalculateRevenueAsync(), () => !IsLoading);
        }

        private async Task LoadPriceAsync()
        {
            try
            {
                IsLoading = true;
                StatusMessage = "Загрузка текущей цены...";

                CurrentPrice = await _gasPriceService.GetCurrentPriceAsync();

                if (CurrentPrice != null)
                {
                    StatusMessage = $"✓ Цена загружена: {CurrentPrice.PricePer1000m3:N2} {CurrentPrice.Currency}/тыс. м³";
                }
                else
                {
                    StatusMessage = "Цена не найдена";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = "✗ Ошибка загрузки цены";
                _dialogService.ShowError($"Ошибка: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task LoadPricesAsync()
        {
            try
            {
                IsLoading = true;
                StatusMessage = "Загрузка цен...";

                var startDate = DateTime.Today.AddMonths(-1);
                var endDate = DateTime.Today;

                var prices = await _gasPriceService.GetPricesFromDatabaseAsync(startDate, endDate);

                Prices.Clear();
                foreach (var price in prices)
                {
                    Prices.Add(price);
                }

                StatusMessage = $"✓ Загружено цен: {Prices.Count}";
            }
            catch (Exception ex)
            {
                StatusMessage = "✗ Ошибка загрузки цен";
                _dialogService.ShowError($"Ошибка: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task UpdatePricesAsync()
        {
            try
            {
                IsLoading = true;
                StatusMessage = "Обновление цен...";

                var startDate = DateTime.Today.AddDays(-7);
                var endDate = DateTime.Today;

                await _gasPriceService.UpdatePricesAsync(startDate, endDate);

                StatusMessage = "✓ Цены успешно обновлены";
                _dialogService.ShowMessage("Цены успешно обновлены", "Успех");
            }
            catch (Exception ex)
            {
                StatusMessage = "✗ Ошибка обновления цен";
                _dialogService.ShowError($"Ошибка: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task LoadExchangeRateAsync()
        {
            try
            {
                IsLoading = true;
                StatusMessage = "Загрузка курса валют...";

                ExchangeRate = await _apiService.GetExchangeRateAsync("USD", "RUB");

                StatusMessage = $"✓ Курс USD/RUB: {ExchangeRate:N2}";
            }
            catch (Exception ex)
            {
                StatusMessage = "✗ Ошибка загрузки курса";
                _dialogService.ShowError($"Ошибка: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        private async Task CalculateRevenueAsync()
        {
            try
            {
                IsLoading = true;
                StatusMessage = "Расчет выручки...";

                var startDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                var endDate = DateTime.Now;
                var totalVolume = await _dataService.GetTotalGasVolumeAsync(startDate, endDate);

                var price = await _gasPriceService.GetCurrentPriceAsync();

                if (price != null)
                {
                    var revenue = totalVolume * price.PricePer1000m3;
                    StatusMessage = $"✓ Выручка за месяц: {revenue:N2} {price.Currency}";
                    _dialogService.ShowMessage(
                        $"Объем добычи: {totalVolume:N2} тыс. м³\n" +
                        $"Цена: {price.PricePer1000m3:N2} {price.Currency}/тыс. м³\n" +
                        $"Выручка: {revenue:N2} {price.Currency}",
                        "Расчет выручки");
                }
            }
            catch (Exception ex)
            {
                StatusMessage = "✗ Ошибка расчета";
                _dialogService.ShowError($"Ошибка: {ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }
    }
}