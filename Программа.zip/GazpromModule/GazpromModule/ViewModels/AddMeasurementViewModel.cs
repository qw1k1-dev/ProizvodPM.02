﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;

namespace GazpromModule.ViewModels
{
    public class AddMeasurementViewModel : BaseViewModel
    {
        private readonly DataService _dataService;
        private readonly Well _well;
        private readonly string _operatorName;

        private DateTime? _measurementDate;
        private string _gasVolume;
        private string _pressure;
        private string _temperature;
        private string _errorMessage;

        public string WellNumber => _well?.WellNumber ?? "";

        public DateTime? MeasurementDate
        {
            get => _measurementDate;
            set => SetProperty(ref _measurementDate, value);
        }

        public string GasVolume
        {
            get => _gasVolume;
            set => SetProperty(ref _gasVolume, value);
        }

        public string Pressure
        {
            get => _pressure;
            set => SetProperty(ref _pressure, value);
        }

        public string Temperature
        {
            get => _temperature;
            set => SetProperty(ref _temperature, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public ICommand SaveCommand { get; }

        public event EventHandler MeasurementAdded;

        public AddMeasurementViewModel(DataService dataService, Well well, string operatorName = "Текущий оператор")
        {
            _dataService = dataService;
            _well = well;
            _operatorName = operatorName;

            // Устанавливаем значения по умолчанию
            MeasurementDate = DateTime.Now;

            SaveCommand = new RelayCommand(async () => await SaveAsync());
        }

        private async Task SaveAsync()
        {
            try
            {
                // Валидация
                if (!MeasurementDate.HasValue)
                {
                    ErrorMessage = "Укажите дату замера";
                    return;
                }

                if (!decimal.TryParse(GasVolume, out decimal gasVolumeValue) || gasVolumeValue < 0)
                {
                    ErrorMessage = "Введите корректный объём газа (неотрицательное число)";
                    return;
                }

                if (!decimal.TryParse(Pressure, out decimal pressureValue) || pressureValue < 0)
                {
                    ErrorMessage = "Введите корректное давление (неотрицательное число)";
                    return;
                }

                if (!decimal.TryParse(Temperature, out decimal temperatureValue))
                {
                    ErrorMessage = "Введите корректную температуру";
                    return;
                }

                var measurement = new WellMeasurement
                {
                    WellID = _well.WellID,
                    MeasurementDate = MeasurementDate.Value,
                    GasVolume = gasVolumeValue,
                    Pressure = pressureValue,
                    Temperature = temperatureValue,
                    OperatorName = _operatorName
                };

                await _dataService.AddMeasurementAsync(measurement);

                // Вызываем событие об успешном добавлении
                MeasurementAdded?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка сохранения: {ex.Message}";
            }
        }
    }
}