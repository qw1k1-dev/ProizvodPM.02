﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;
using GazpromModule.Views;

namespace GazpromModule.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        private readonly DataService _dataService;
        private readonly DialogService _dialogService;
        private readonly User _currentUser;

        private ObservableCollection<Well> _wells;
        private ObservableCollection<WellMeasurement> _measurements;
        private ObservableCollection<Maintenance> _maintenances;
        private Well _selectedWell;
        private WellMeasurement _selectedMeasurement;
        private Maintenance _selectedMaintenance;
        private string _statusMessage;

        public ObservableCollection<Well> Wells
        {
            get => _wells;
            set => SetProperty(ref _wells, value);
        }

        public ObservableCollection<WellMeasurement> Measurements
        {
            get => _measurements;
            set => SetProperty(ref _measurements, value);
        }

        public ObservableCollection<Maintenance> Maintenances
        {
            get => _maintenances;
            set => SetProperty(ref _maintenances, value);
        }

        public Well SelectedWell
        {
            get => _selectedWell;
            set
            {
                if (SetProperty(ref _selectedWell, value))
                {
                    LoadWellDataAsync();
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        public WellMeasurement SelectedMeasurement
        {
            get => _selectedMeasurement;
            set
            {
                if (SetProperty(ref _selectedMeasurement, value))
                {
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        public Maintenance SelectedMaintenance
        {
            get => _selectedMaintenance;
            set
            {
                if (SetProperty(ref _selectedMaintenance, value))
                {
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set => SetProperty(ref _statusMessage, value);
        }

        public string UserName
        {
            get
            {
                if (_currentUser == null)
                    return "Пользователь";

                if (!string.IsNullOrWhiteSpace(_currentUser.FullName))
                    return _currentUser.FullName.Trim();

                if (!string.IsNullOrWhiteSpace(_currentUser.Username))
                    return _currentUser.Username.Trim();

                return "Пользователь";
            }
        }

        public string UserRole
        {
            get
            {
                if (_currentUser == null)
                    return "";

                if (!string.IsNullOrWhiteSpace(_currentUser.Role))
                {
                    var role = _currentUser.Role.Trim();
                    if (role.Contains("System.Windows.Controls.ComboBoxItem"))
                    {
                        role = role.Replace("System.Windows.Controls.ComboBoxItem: ", "");
                    }
                    return role;
                }

                return "";
            }
        }

        // Команды для скважин
        public ICommand RefreshCommand { get; }
        public ICommand AddWellCommand { get; }
        public ICommand EditWellCommand { get; }
        public ICommand DeleteWellCommand { get; }

        // Команды для замеров
        public ICommand AddMeasurementCommand { get; }
        public ICommand EditMeasurementCommand { get; }
        public ICommand DeleteMeasurementCommand { get; }

        // Команды для обслуживания
        public ICommand AddMaintenanceCommand { get; }
        public ICommand EditMaintenanceCommand { get; }
        public ICommand DeleteMaintenanceCommand { get; }

        // Команда выхода
        public ICommand LogoutCommand { get; }

        // ViewModel для API
        public ApiViewModel ApiViewModel { get; }

        public event EventHandler LogoutRequested;

        public MainViewModel(
            DataService dataService,
            DialogService dialogService,
            User currentUser,
            ApiService apiService,
            GasPriceService gasPriceService)
        {
            _dataService = dataService;
            _dialogService = dialogService;
            _currentUser = currentUser;

            Wells = new ObservableCollection<Well>();
            Measurements = new ObservableCollection<WellMeasurement>();
            Maintenances = new ObservableCollection<Maintenance>();

            // Команды для скважин
            RefreshCommand = new RelayCommand(async () => await LoadDataAsync());
            AddWellCommand = new RelayCommand(ShowAddWellDialog);
            EditWellCommand = new RelayCommand(ShowEditWellDialog, () => SelectedWell != null);
            DeleteWellCommand = new RelayCommand(async () => await DeleteWellAsync(), () => SelectedWell != null);

            // Команды для замеров
            AddMeasurementCommand = new RelayCommand(ShowAddMeasurementDialog, () => SelectedWell != null);
            EditMeasurementCommand = new RelayCommand(ShowEditMeasurementDialog, () => SelectedMeasurement != null);
            DeleteMeasurementCommand = new RelayCommand(async () => await DeleteMeasurementAsync(), () => SelectedMeasurement != null);

            // Команды для обслуживания
            AddMaintenanceCommand = new RelayCommand(ShowAddMaintenanceDialog, () => SelectedWell != null);
            EditMaintenanceCommand = new RelayCommand(ShowEditMaintenanceDialog, () => SelectedMaintenance != null);
            DeleteMaintenanceCommand = new RelayCommand(async () => await DeleteMaintenanceAsync(), () => SelectedMaintenance != null);

            // Команда выхода
            LogoutCommand = new RelayCommand(Logout);

            // Создаем ViewModel для API
            ApiViewModel = new ApiViewModel(apiService, gasPriceService, dataService, dialogService);

            // Загружаем данные
            _ = LoadDataAsync();
        }

        private async Task LoadDataAsync()
        {
            try
            {
                StatusMessage = "Загрузка данных...";

                var wells = await _dataService.GetWellsAsync();

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Wells.Clear();
                    foreach (var well in wells)
                    {
                        Wells.Add(well);
                    }
                });

                var maintenances = await _dataService.GetMaintenancesAsync();

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Maintenances.Clear();
                    foreach (var maintenance in maintenances)
                    {
                        Maintenances.Add(maintenance);
                    }
                });

                StatusMessage = $"Загружено скважин: {Wells.Count}, обслуживаний: {Maintenances.Count}";
                CommandManager.InvalidateRequerySuggested();
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки: {ex.Message}";
                _dialogService.ShowError($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private async Task LoadWellDataAsync()
        {
            if (SelectedWell == null) return;

            try
            {
                StatusMessage = $"Загрузка замеров для скважины {SelectedWell.WellNumber}...";

                var measurements = await _dataService.GetMeasurementsAsync(SelectedWell.WellID);

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Measurements.Clear();
                    foreach (var measurement in measurements)
                    {
                        Measurements.Add(measurement);
                    }
                });

                StatusMessage = $"Загружено замеров: {Measurements.Count}";
                CommandManager.InvalidateRequerySuggested();
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки замеров: {ex.Message}";
                _dialogService.ShowError($"Ошибка загрузки замеров: {ex.Message}");
            }
        }

        private void ShowAddWellDialog()
        {
            var addWellViewModel = new AddWellViewModel(_dataService);
            var addWellDialog = new AddWellDialog(addWellViewModel);
            addWellDialog.Owner = Application.Current.MainWindow;

            if (addWellDialog.ShowDialog() == true)
            {
                _ = LoadDataAsync();
                _dialogService.ShowMessage("Скважина успешно добавлена", "Успех");
            }
        }

        private void ShowEditWellDialog()
        {
            if (SelectedWell == null)
            {
                _dialogService.ShowError("Выберите скважину для редактирования");
                return;
            }

            var editWellViewModel = new EditWellViewModel(_dataService, SelectedWell);
            var editWellDialog = new EditWellDialog(editWellViewModel);
            editWellDialog.Owner = Application.Current.MainWindow;

            if (editWellDialog.ShowDialog() == true)
            {
                _ = LoadDataAsync();
                _dialogService.ShowMessage("Скважина успешно обновлена", "Успех");
            }
        }

        private async Task DeleteWellAsync()
        {
            if (SelectedWell == null)
            {
                _dialogService.ShowError("Выберите скважину для удаления");
                return;
            }

            if (_dialogService.ShowConfirmation($"Вы уверены, что хотите удалить скважину {SelectedWell.WellNumber}?", "Подтверждение удаления"))
            {
                try
                {
                    await _dataService.DeleteWellAsync(SelectedWell.WellID);
                    _ = LoadDataAsync();
                    _dialogService.ShowMessage("Скважина успешно удалена", "Успех");
                }
                catch (Exception ex)
                {
                    _dialogService.ShowError($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        private void ShowAddMeasurementDialog()
        {
            if (SelectedWell == null)
            {
                _dialogService.ShowError("Выберите скважину в списке слева");
                return;
            }

            var addMeasurementViewModel = new AddMeasurementViewModel(_dataService, SelectedWell, UserName);
            var addMeasurementDialog = new AddMeasurementDialog(addMeasurementViewModel);
            addMeasurementDialog.Owner = Application.Current.MainWindow;

            if (addMeasurementDialog.ShowDialog() == true)
            {
                _ = LoadWellDataAsync();
                _dialogService.ShowMessage("Замер успешно добавлен", "Успех");
            }
        }

        private void ShowEditMeasurementDialog()
        {
            if (SelectedMeasurement == null)
            {
                _dialogService.ShowError("Выберите замер для редактирования");
                return;
            }

            var editMeasurementViewModel = new EditMeasurementViewModel(_dataService, SelectedMeasurement);
            var editMeasurementDialog = new EditMeasurementDialog(editMeasurementViewModel);
            editMeasurementDialog.Owner = Application.Current.MainWindow;

            if (editMeasurementDialog.ShowDialog() == true)
            {
                _ = LoadWellDataAsync();
                _dialogService.ShowMessage("Замер успешно обновлён", "Успех");
            }
        }

        private async Task DeleteMeasurementAsync()
        {
            if (SelectedMeasurement == null)
            {
                _dialogService.ShowError("Выберите замер для удаления");
                return;
            }

            if (_dialogService.ShowConfirmation("Вы уверены, что хотите удалить выбранный замер?", "Подтверждение удаления"))
            {
                try
                {
                    await _dataService.DeleteMeasurementAsync(SelectedMeasurement.MeasurementID);
                    _ = LoadWellDataAsync();
                    _dialogService.ShowMessage("Замер успешно удалён", "Успех");
                }
                catch (Exception ex)
                {
                    _dialogService.ShowError($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        private void ShowAddMaintenanceDialog()
        {
            if (SelectedWell == null)
            {
                _dialogService.ShowError("Выберите скважину в списке слева");
                return;
            }

            var addMaintenanceViewModel = new AddMaintenanceViewModel(_dataService, SelectedWell);
            var addMaintenanceDialog = new AddMaintenanceDialog(addMaintenanceViewModel);
            addMaintenanceDialog.Owner = Application.Current.MainWindow;

            if (addMaintenanceDialog.ShowDialog() == true)
            {
                _ = LoadDataAsync();
                _dialogService.ShowMessage("Запись об обслуживании успешно добавлена", "Успех");
            }
        }

        private void ShowEditMaintenanceDialog()
        {
            if (SelectedMaintenance == null)
            {
                _dialogService.ShowError("Выберите запись для редактирования");
                return;
            }

            var editMaintenanceViewModel = new EditMaintenanceViewModel(_dataService, SelectedMaintenance);
            var editMaintenanceDialog = new EditMaintenanceDialog(editMaintenanceViewModel);
            editMaintenanceDialog.Owner = Application.Current.MainWindow;

            if (editMaintenanceDialog.ShowDialog() == true)
            {
                _ = LoadDataAsync();
                _dialogService.ShowMessage("Запись успешно обновлена", "Успех");
            }
        }

        private async Task DeleteMaintenanceAsync()
        {
            if (SelectedMaintenance == null)
            {
                _dialogService.ShowError("Выберите запись для удаления");
                return;
            }

            if (_dialogService.ShowConfirmation("Вы уверены, что хотите удалить выбранную запись?", "Подтверждение удаления"))
            {
                try
                {
                    await _dataService.DeleteMaintenanceAsync(SelectedMaintenance.MaintenanceID);
                    _ = LoadDataAsync();
                    _dialogService.ShowMessage("Запись успешно удалена", "Успех");
                }
                catch (Exception ex)
                {
                    _dialogService.ShowError($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        private void Logout()
        {
            if (_dialogService.ShowConfirmation("Вы уверены, что хотите выйти из системы?", "Выход"))
            {
                LogoutRequested?.Invoke(this, EventArgs.Empty);
            }
        }
    }
}