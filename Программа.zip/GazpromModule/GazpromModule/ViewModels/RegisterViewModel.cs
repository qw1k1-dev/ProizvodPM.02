﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using GazpromModule.Services;

namespace GazpromModule.ViewModels
{
    public class RegisterViewModel : BaseViewModel
    {
        private readonly AuthService _authService;

        private string _username;
        private string _password;
        private string _confirmPassword;
        private string _fullName;
        private string _role;
        private string _errorMessage;

        public string Username
        {
            get => _username;
            set => SetProperty(ref _username, value);
        }

        public string Password
        {
            get => _password;
            set => SetProperty(ref _password, value);
        }

        public string ConfirmPassword
        {
            get => _confirmPassword;
            set => SetProperty(ref _confirmPassword, value);
        }

        public string FullName
        {
            get => _fullName;
            set => SetProperty(ref _fullName, value);
        }

        public string Role
        {
            get => _role;
            set => SetProperty(ref _role, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public ICommand RegisterCommand { get; }

        public event EventHandler RegistrationSuccessful;

        public RegisterViewModel(AuthService authService)
        {
            _authService = authService;

            // Устанавливаем роль по умолчанию
            _role = "Инженер";

            RegisterCommand = new RelayCommand(async () => await RegisterAsync());
        }

        private async Task RegisterAsync()
        {
            try
            {
                // Валидация
                if (string.IsNullOrWhiteSpace(Username))
                {
                    ErrorMessage = "Введите логин";
                    return;
                }

                if (string.IsNullOrWhiteSpace(Password))
                {
                    ErrorMessage = "Введите пароль";
                    return;
                }

                if (Password != ConfirmPassword)
                {
                    ErrorMessage = "Пароли не совпадают";
                    return;
                }

                if (Password.Length < 6)
                {
                    ErrorMessage = "Пароль должен быть не менее 6 символов";
                    return;
                }

                if (string.IsNullOrWhiteSpace(FullName))
                {
                    ErrorMessage = "Введите ФИО";
                    return;
                }

                if (string.IsNullOrWhiteSpace(Role))
                {
                    ErrorMessage = "Выберите роль";
                    return;
                }

                // Очищаем значение роли от возможного мусора
                var cleanRole = Role.Replace("System.Windows.Controls.ComboBoxItem: ", "");

                var result = await _authService.RegisterAsync(Username, Password, FullName.Trim(), cleanRole);

                if (result)
                {
                    RegistrationSuccessful?.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    ErrorMessage = "Пользователь с таким логином уже существует";
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка регистрации: {ex.Message}";
            }
        }
    }
}