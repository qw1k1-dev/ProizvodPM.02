﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;

namespace GazpromModule.ViewModels
{
    public class EditMeasurementViewModel : BaseViewModel
    {
        private readonly DataService _dataService;
        private readonly WellMeasurement _measurement;

        private DateTime? _measurementDate;
        private string _gasVolume;
        private string _pressure;
        private string _temperature;
        private string _errorMessage;

        public string WellNumber => _measurement?.Well?.WellNumber ?? "";

        public DateTime? MeasurementDate
        {
            get => _measurementDate;
            set => SetProperty(ref _measurementDate, value);
        }

        public string GasVolume
        {
            get => _gasVolume;
            set => SetProperty(ref _gasVolume, value);
        }

        public string Pressure
        {
            get => _pressure;
            set => SetProperty(ref _pressure, value);
        }

        public string Temperature
        {
            get => _temperature;
            set => SetProperty(ref _temperature, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public ICommand SaveCommand { get; }

        public event EventHandler MeasurementUpdated;

        public EditMeasurementViewModel(DataService dataService, WellMeasurement measurement)
        {
            _dataService = dataService;
            _measurement = measurement;

            // Заполняем поля текущими значениями
            MeasurementDate = measurement.MeasurementDate;
            GasVolume = measurement.GasVolume?.ToString() ?? "";
            Pressure = measurement.Pressure?.ToString() ?? "";
            Temperature = measurement.Temperature?.ToString() ?? "";

            SaveCommand = new RelayCommand(async () => await SaveAsync());
        }

        private async Task SaveAsync()
        {
            try
            {
                // Валидация
                if (!MeasurementDate.HasValue)
                {
                    ErrorMessage = "Укажите дату замера";
                    return;
                }

                if (!decimal.TryParse(GasVolume, out decimal gasVolumeValue) || gasVolumeValue < 0)
                {
                    ErrorMessage = "Введите корректный объём газа (неотрицательное число)";
                    return;
                }

                if (!decimal.TryParse(Pressure, out decimal pressureValue) || pressureValue < 0)
                {
                    ErrorMessage = "Введите корректное давление (неотрицательное число)";
                    return;
                }

                if (!decimal.TryParse(Temperature, out decimal temperatureValue))
                {
                    ErrorMessage = "Введите корректную температуру";
                    return;
                }

                _measurement.MeasurementDate = MeasurementDate.Value;
                _measurement.GasVolume = gasVolumeValue;
                _measurement.Pressure = pressureValue;
                _measurement.Temperature = temperatureValue;

                await _dataService.UpdateMeasurementAsync(_measurement);

                MeasurementUpdated?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка сохранения: {ex.Message}";
            }
        }
    }
}