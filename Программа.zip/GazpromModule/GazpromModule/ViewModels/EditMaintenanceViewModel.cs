﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;

namespace GazpromModule.ViewModels
{
    public class EditMaintenanceViewModel : BaseViewModel
    {
        private readonly DataService _dataService;
        private readonly Maintenance _maintenance;

        private string _workType;
        private DateTime? _startDate;
        private DateTime? _endDate;
        private string _description;
        private string _responsiblePerson;
        private string _result;
        private string _errorMessage;

        public string WellNumber => _maintenance?.Well?.WellNumber ?? "";

        public string WorkType
        {
            get => _workType;
            set => SetProperty(ref _workType, value);
        }

        public DateTime? StartDate
        {
            get => _startDate;
            set => SetProperty(ref _startDate, value);
        }

        public DateTime? EndDate
        {
            get => _endDate;
            set => SetProperty(ref _endDate, value);
        }

        public string Description
        {
            get => _description;
            set => SetProperty(ref _description, value);
        }

        public string ResponsiblePerson
        {
            get => _responsiblePerson;
            set => SetProperty(ref _responsiblePerson, value);
        }

        public string Result
        {
            get => _result;
            set => SetProperty(ref _result, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public ICommand SaveCommand { get; }

        public event EventHandler MaintenanceUpdated;

        public EditMaintenanceViewModel(DataService dataService, Maintenance maintenance)
        {
            _dataService = dataService;
            _maintenance = maintenance;

            // Заполняем поля текущими значениями
            WorkType = maintenance.WorkType;
            StartDate = maintenance.StartDate;
            EndDate = maintenance.EndDate;
            Description = maintenance.Description;
            ResponsiblePerson = maintenance.ResponsiblePerson;
            Result = maintenance.Result;

            SaveCommand = new RelayCommand(async () => await SaveAsync());
        }

        private async Task SaveAsync()
        {
            try
            {
                // Валидация
                if (string.IsNullOrWhiteSpace(WorkType))
                {
                    ErrorMessage = "Выберите тип работ";
                    return;
                }

                if (!StartDate.HasValue)
                {
                    ErrorMessage = "Укажите дату начала работ";
                    return;
                }

                if (EndDate.HasValue && StartDate.HasValue && EndDate.Value < StartDate.Value)
                {
                    ErrorMessage = "Дата окончания не может быть раньше даты начала";
                    return;
                }

                _maintenance.WorkType = WorkType;
                _maintenance.StartDate = StartDate;
                _maintenance.EndDate = EndDate;
                _maintenance.Description = Description;
                _maintenance.ResponsiblePerson = ResponsiblePerson;
                _maintenance.Result = Result;

                await _dataService.UpdateMaintenanceAsync(_maintenance);

                MaintenanceUpdated?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка сохранения: {ex.Message}";
            }
        }
    }
}