﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using GazpromModule.Models;
using GazpromModule.Services;
using GazpromModule.Views;

namespace GazpromModule.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        private readonly AuthService _authService;
        private readonly DialogService _dialogService;

        private string _username;
        private string _password;
        private bool _isLoading;
        private string _errorMessage;
        private User _currentUser;

        public string Username
        {
            get => _username;
            set
            {
                if (SetProperty(ref _username, value))
                {
                    (LoginCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                if (SetProperty(ref _password, value))
                {
                    (LoginCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }

        public bool IsLoading
        {
            get => _isLoading;
            set
            {
                if (SetProperty(ref _isLoading, value))
                {
                    (LoginCommand as RelayCommand)?.RaiseCanExecuteChanged();
                }
            }
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetProperty(ref _errorMessage, value);
        }

        public User CurrentUser
        {
            get => _currentUser;
            private set => SetProperty(ref _currentUser, value);
        }

        public ICommand LoginCommand { get; }
        public ICommand RegisterCommand { get; }

        public event EventHandler LoginSuccessful;

        public LoginViewModel(AuthService authService, DialogService dialogService)
        {
            _authService = authService;
            _dialogService = dialogService;

            LoginCommand = new RelayCommand(async () => await LoginAsync(), () => CanLogin());
            RegisterCommand = new RelayCommand(ShowRegisterDialog);
        }

        private bool CanLogin()
        {
            return !string.IsNullOrWhiteSpace(Username) &&
                   !string.IsNullOrWhiteSpace(Password) &&
                   !IsLoading;
        }

        private async Task LoginAsync()
        {
            try
            {
                IsLoading = true;
                ErrorMessage = string.Empty;

                var user = await _authService.AuthenticateAsync(Username, Password);

                if (user != null)
                {
                    CurrentUser = user;
                    LoginSuccessful?.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    ErrorMessage = "Неверный логин или пароль";
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Ошибка: {ex.Message}";
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void ShowRegisterDialog()
        {
            var registerViewModel = new RegisterViewModel(_authService);
            var registerWindow = new RegisterWindow(registerViewModel);
            registerWindow.Owner = Application.Current.MainWindow;

            if (registerWindow.ShowDialog() == true)
            {
                _dialogService.ShowMessage("Регистрация успешно завершена. Теперь вы можете войти в систему.", "Успех");
            }
        }
    }
}