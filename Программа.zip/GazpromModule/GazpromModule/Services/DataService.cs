﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GazpromModule.Data;
using GazpromModule.Models;

namespace GazpromModule.Services
{
    public class DataService
    {
        private readonly AppDbContext _context;

        public DataService(AppDbContext context)
        {
            _context = context;
        }

        // ==================== МЕТОДЫ ДЛЯ РАБОТЫ СО СКВАЖИНАМИ ====================

        public async Task<List<Well>> GetWellsAsync()
        {
            return await _context.Wells
                .Include(w => w.Field)
                .OrderBy(w => w.WellNumber)
                .ToListAsync();
        }

        public async Task<Well> GetWellByIdAsync(int wellId)
        {
            return await _context.Wells
                .Include(w => w.Field)
                .Include(w => w.Measurements)
                .FirstOrDefaultAsync(w => w.WellID == wellId);
        }

        public async Task AddWellAsync(Well well)
        {
            _context.Wells.Add(well);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateWellAsync(Well well)
        {
            _context.Wells.Update(well);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteWellAsync(int wellId)
        {
            var well = await _context.Wells.FindAsync(wellId);
            if (well != null)
            {
                _context.Wells.Remove(well);
                await _context.SaveChangesAsync();
            }
        }

        // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С ЗАМЕРАМИ ====================

        public async Task<List<WellMeasurement>> GetMeasurementsAsync(int? wellId = null,
                                                                       DateTime? startDate = null,
                                                                       DateTime? endDate = null)
        {
            var query = _context.WellMeasurements
                .Include(m => m.Well)
                .AsQueryable();

            if (wellId.HasValue)
                query = query.Where(m => m.WellID == wellId.Value);

            if (startDate.HasValue)
                query = query.Where(m => m.MeasurementDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(m => m.MeasurementDate <= endDate.Value);

            // Ограничиваем количество загружаемых записей для производительности
            return await query
                .OrderByDescending(m => m.MeasurementDate)
                .Take(1000)
                .ToListAsync();
        }

        public async Task<WellMeasurement> GetMeasurementByIdAsync(long measurementId)
        {
            return await _context.WellMeasurements
                .Include(m => m.Well)
                .FirstOrDefaultAsync(m => m.MeasurementID == measurementId);
        }

        public async Task AddMeasurementAsync(WellMeasurement measurement)
        {
            _context.WellMeasurements.Add(measurement);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateMeasurementAsync(WellMeasurement measurement)
        {
            _context.WellMeasurements.Update(measurement);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteMeasurementAsync(long measurementId)
        {
            var measurement = await _context.WellMeasurements.FindAsync(measurementId);
            if (measurement != null)
            {
                _context.WellMeasurements.Remove(measurement);
                await _context.SaveChangesAsync();
            }
        }

        // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С ОБСЛУЖИВАНИЕМ ====================

        public async Task<List<Maintenance>> GetMaintenancesAsync(int? wellId = null)
        {
            var query = _context.Maintenances
                .Include(m => m.Well)
                .AsQueryable();

            if (wellId.HasValue)
                query = query.Where(m => m.WellID == wellId.Value);

            return await query
                .OrderByDescending(m => m.StartDate)
                .Take(100)
                .ToListAsync();
        }

        public async Task<Maintenance> GetMaintenanceByIdAsync(int maintenanceId)
        {
            return await _context.Maintenances
                .Include(m => m.Well)
                .FirstOrDefaultAsync(m => m.MaintenanceID == maintenanceId);
        }

        public async Task AddMaintenanceAsync(Maintenance maintenance)
        {
            _context.Maintenances.Add(maintenance);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateMaintenanceAsync(Maintenance maintenance)
        {
            _context.Maintenances.Update(maintenance);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteMaintenanceAsync(int maintenanceId)
        {
            var maintenance = await _context.Maintenances.FindAsync(maintenanceId);
            if (maintenance != null)
            {
                _context.Maintenances.Remove(maintenance);
                await _context.SaveChangesAsync();
            }
        }

        // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С МЕСТОРОЖДЕНИЯМИ ====================

        public async Task<List<Field>> GetFieldsAsync()
        {
            return await _context.Fields
                .OrderBy(f => f.FieldName)
                .ToListAsync();
        }

        public async Task<Field> GetFieldByIdAsync(int fieldId)
        {
            return await _context.Fields
                .Include(f => f.Wells)
                .FirstOrDefaultAsync(f => f.FieldID == fieldId);
        }

        public async Task AddFieldAsync(Field field)
        {
            _context.Fields.Add(field);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateFieldAsync(Field field)
        {
            _context.Fields.Update(field);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteFieldAsync(int fieldId)
        {
            var field = await _context.Fields.FindAsync(fieldId);
            if (field != null)
            {
                _context.Fields.Remove(field);
                await _context.SaveChangesAsync();
            }
        }

        // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С ЦЕНАМИ НА ГАЗ ====================

        public async Task<List<GasPrice>> GetGasPricesAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            var query = _context.GasPrices.AsQueryable();

            if (startDate.HasValue)
                query = query.Where(p => p.PriceDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(p => p.PriceDate <= endDate.Value);

            return await query
                .OrderByDescending(p => p.PriceDate)
                .ToListAsync();
        }

        public async Task<GasPrice> GetLatestGasPriceAsync()
        {
            return await _context.GasPrices
                .OrderByDescending(p => p.PriceDate)
                .FirstOrDefaultAsync();
        }

        public async Task AddGasPriceAsync(GasPrice gasPrice)
        {
            _context.GasPrices.Add(gasPrice);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateGasPriceAsync(GasPrice gasPrice)
        {
            _context.GasPrices.Update(gasPrice);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteGasPriceAsync(int priceId)
        {
            var gasPrice = await _context.GasPrices.FindAsync(priceId);
            if (gasPrice != null)
            {
                _context.GasPrices.Remove(gasPrice);
                await _context.SaveChangesAsync();
            }
        }

        // ==================== МЕТОДЫ ДЛЯ ОТЧЁТОВ ====================

        public async Task<decimal> GetTotalGasVolumeAsync(DateTime startDate, DateTime endDate)
        {
            var total = await _context.WellMeasurements
                .Where(m => m.MeasurementDate >= startDate && m.MeasurementDate <= endDate)
                .SumAsync(m => m.GasVolume ?? 0);

            return total;
        }

        public async Task<Dictionary<string, decimal>> GetGasVolumeByWellAsync(DateTime startDate, DateTime endDate)
        {
            var result = await _context.WellMeasurements
                .Where(m => m.MeasurementDate >= startDate && m.MeasurementDate <= endDate)
                .Include(m => m.Well)
                .GroupBy(m => m.Well.WellNumber)
                .Select(g => new { WellNumber = g.Key, TotalVolume = g.Sum(m => m.GasVolume ?? 0) })
                .ToDictionaryAsync(x => x.WellNumber, x => x.TotalVolume);

            return result;
        }

        public async Task<Dictionary<string, decimal>> GetGasVolumeByFieldAsync(DateTime startDate, DateTime endDate)
        {
            var result = await _context.WellMeasurements
                .Where(m => m.MeasurementDate >= startDate && m.MeasurementDate <= endDate)
                .Include(m => m.Well)
                .ThenInclude(w => w.Field)
                .GroupBy(m => m.Well.Field.FieldName)
                .Select(g => new { FieldName = g.Key, TotalVolume = g.Sum(m => m.GasVolume ?? 0) })
                .ToDictionaryAsync(x => x.FieldName, x => x.TotalVolume);

            return result;
        }

        public async Task<int> GetTotalWellsCountAsync()
        {
            return await _context.Wells.CountAsync();
        }

        public async Task<int> GetActiveWellsCountAsync()
        {
            return await _context.Wells
                .Where(w => w.Status == "действующая")
                .CountAsync();
        }

        public async Task<int> GetMeasurementsCountAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            var query = _context.WellMeasurements.AsQueryable();

            if (startDate.HasValue)
                query = query.Where(m => m.MeasurementDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(m => m.MeasurementDate <= endDate.Value);

            return await query.CountAsync();
        }

        // ==================== МЕТОДЫ ДЛЯ ПОЛЬЗОВАТЕЛЕЙ ====================

        public async Task<List<User>> GetUsersAsync()
        {
            return await _context.Users
                .OrderBy(u => u.Username)
                .ToListAsync();
        }

        public async Task<User> GetUserByIdAsync(int userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task<User> GetUserByUsernameAsync(string username)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username);
        }

        public async Task AddUserAsync(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateUserAsync(User user)
        {
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
            }
        }
    }
}