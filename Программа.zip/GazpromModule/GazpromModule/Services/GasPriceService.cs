﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GazpromModule.Data;
using GazpromModule.Models;
using Microsoft.EntityFrameworkCore;

namespace GazpromModule.Services
{
    public class GasPriceService
    {
        private readonly AppDbContext _context;
        private readonly ApiService _apiService;

        public GasPriceService(AppDbContext context, ApiService apiService)
        {
            _context = context;
            _apiService = apiService;
        }

        // Получение текущей цены на газ
        public async Task<GasPrice> GetCurrentPriceAsync()
        {
            try
            {
                // Получаем цену из API
                var apiPrice = await _apiService.GetGasPriceAsync(DateTime.Today);

                // Сохраняем в БД
                var gasPrice = new GasPrice
                {
                    PriceDate = apiPrice.PriceDate,
                    PricePer1000m3 = apiPrice.PricePer1000m3,
                    Currency = apiPrice.Currency
                };

                // Проверяем, есть ли уже цена за эту дату
                var existingPrice = await _context.GasPrices
                    .FirstOrDefaultAsync(p => p.PriceDate == gasPrice.PriceDate);

                if (existingPrice == null)
                {
                    _context.GasPrices.Add(gasPrice);
                    await _context.SaveChangesAsync();
                    return gasPrice;
                }
                else
                {
                    return existingPrice;
                }
            }
            catch (Exception)
            {
                // Если API недоступен, берем последнюю цену из БД
                var lastPrice = await _context.GasPrices
                    .OrderByDescending(p => p.PriceDate)
                    .FirstOrDefaultAsync();

                return lastPrice;
            }
        }

        // Обновление цен за период
        public async Task UpdatePricesAsync(DateTime startDate, DateTime endDate)
        {
            try
            {
                var apiPrices = await _apiService.GetGasPricesAsync(startDate, endDate);

                foreach (var price in apiPrices)
                {
                    var existingPrice = await _context.GasPrices
                        .FirstOrDefaultAsync(p => p.PriceDate == price.PriceDate);

                    if (existingPrice == null)
                    {
                        _context.GasPrices.Add(price);
                    }
                    else
                    {
                        existingPrice.PricePer1000m3 = price.PricePer1000m3;
                        existingPrice.Currency = price.Currency;
                        _context.GasPrices.Update(existingPrice);
                    }
                }

                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при обновлении цен: {ex.Message}", ex);
            }
        }

        // Получение цен из БД
        public async Task<List<GasPrice>> GetPricesFromDatabaseAsync(DateTime? startDate = null, DateTime? endDate = null)
        {
            var query = _context.GasPrices.AsQueryable();

            if (startDate.HasValue)
                query = query.Where(p => p.PriceDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(p => p.PriceDate <= endDate.Value);

            return await query
                .OrderByDescending(p => p.PriceDate)
                .ToListAsync();
        }

        // Расчет стоимости добытого газа
        public async Task<decimal> CalculateRevenueAsync(decimal gasVolume, DateTime date)
        {
            var price = await GetCurrentPriceAsync();

            if (price == null)
                return 0;

            return gasVolume * price.PricePer1000m3;
        }
    }
}