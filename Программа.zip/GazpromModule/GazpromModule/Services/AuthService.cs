﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GazpromModule.Data;
using GazpromModule.Models;

namespace GazpromModule.Services
{
    public class AuthService
    {
        private readonly AppDbContext _context;

        public AuthService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var passwordHash = HashPassword(password);

            // Для отладки можно вывести хеш в консоль
            System.Diagnostics.Debug.WriteLine($"Username: {username}");
            System.Diagnostics.Debug.WriteLine($"Password: {password}");
            System.Diagnostics.Debug.WriteLine($"Hash: {passwordHash}");

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username &&
                                         u.PasswordHash == passwordHash &&
                                         u.IsActive);

            return user;
        }

        public async Task<bool> RegisterAsync(string username, string password, string fullName, string role)
        {
            if (await _context.Users.AnyAsync(u => u.Username == username))
                return false;

            var cleanUsername = username?.Trim() ?? "";
            var cleanFullName = fullName?.Trim() ?? "";
            var cleanRole = role?.Trim() ?? "Инженер";

            if (cleanRole.Contains("System.Windows.Controls.ComboBoxItem"))
            {
                cleanRole = cleanRole.Replace("System.Windows.Controls.ComboBoxItem: ", "");
            }

            var user = new User
            {
                Username = cleanUsername,
                PasswordHash = HashPassword(password),
                FullName = cleanFullName,
                Role = cleanRole,
                IsActive = true
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return true;
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }
    }
}