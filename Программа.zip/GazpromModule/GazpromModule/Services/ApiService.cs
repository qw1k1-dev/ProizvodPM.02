﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using GazpromModule.Models;

namespace GazpromModule.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;
        private readonly JsonSerializerOptions _jsonOptions;

        public ApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.Timeout = TimeSpan.FromSeconds(30);

            _jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                WriteIndented = true
            };
        }

        // Получение курса валют (реальный бесплатный API)
        public async Task<decimal> GetExchangeRateAsync(string fromCurrency, string toCurrency)
        {
            try
            {
                var response = await _httpClient.GetAsync($"https://open.er-api.com/v6/latest/{fromCurrency}");
                response.EnsureSuccessStatusCode();

                var json = await response.Content.ReadAsStringAsync();
                var data = JsonSerializer.Deserialize<ExchangeRateResponse>(json, _jsonOptions);

                if (data != null && data.Rates != null && data.Rates.ContainsKey(toCurrency))
                {
                    return data.Rates[toCurrency];
                }

                throw new Exception($"Курс {fromCurrency}->{toCurrency} не найден");
            }
            catch (HttpRequestException ex)
            {
                throw new Exception($"Ошибка HTTP: {ex.Message}", ex);
            }
        }

        // Получение цены на газ (имитация)
        public async Task<GasPrice> GetGasPriceAsync(DateTime date)
        {
            try
            {
                await Task.Delay(200);

                var basePrice = 4500m;
                var random = new Random();
                var variation = random.Next(-300, 300);

                return new GasPrice
                {
                    PriceDate = date,
                    PricePer1000m3 = basePrice + variation,
                    Currency = "RUB"
                };
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка получения цены: {ex.Message}", ex);
            }
        }

        // Получение цен на газ за период
        public async Task<List<GasPrice>> GetGasPricesAsync(DateTime startDate, DateTime endDate)
        {
            try
            {
                var result = new List<GasPrice>();
                var random = new Random();

                for (var date = startDate; date <= endDate; date = date.AddDays(1))
                {
                    var basePrice = 4500m;
                    var variation = random.Next(-300, 300);

                    result.Add(new GasPrice
                    {
                        PriceDate = date,
                        PricePer1000m3 = basePrice + variation,
                        Currency = "RUB"
                    });

                    await Task.Delay(10);
                }

                return result;
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка получения цен: {ex.Message}", ex);
            }
        }
    }

    // Модель для API курсов валют
    public class ExchangeRateResponse
    {
        public string Base { get; set; }
        public Dictionary<string, decimal> Rates { get; set; }
    }
}