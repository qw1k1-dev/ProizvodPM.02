﻿using System;
using System.Collections.Generic;
using System.IO;
using ClosedXML.Excel;
using GazpromModule.Models;

namespace GazpromModule.Services
{
    public class ExcelExportService
    {
        public void ExportWellsToExcel(IEnumerable<Well> wells, string filePath)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Скважины");

                // Заголовки
                worksheet.Cell(1, 1).Value = "Номер скважины";
                worksheet.Cell(1, 2).Value = "Месторождение";
                worksheet.Cell(1, 3).Value = "Тип";
                worksheet.Cell(1, 4).Value = "Глубина (м)";
                worksheet.Cell(1, 5).Value = "Статус";
                worksheet.Cell(1, 6).Value = "Дата ввода";

                // Стиль заголовков
                var headerRow = worksheet.Row(1);
                headerRow.Style.Font.Bold = true;
                headerRow.Style.Fill.BackgroundColor = XLColor.LightBlue;

                // Данные
                int row = 2;
                foreach (var well in wells)
                {
                    worksheet.Cell(row, 1).Value = well.WellNumber;
                    worksheet.Cell(row, 2).Value = well.Field?.FieldName ?? "";
                    worksheet.Cell(row, 3).Value = well.WellType;
                    worksheet.Cell(row, 4).Value = well.Depth ?? 0;
                    worksheet.Cell(row, 5).Value = well.Status;
                    worksheet.Cell(row, 6).Value = well.CommissioningDate?.ToString("dd.MM.yyyy") ?? "";
                    row++;
                }

                // Автоподбор ширины
                worksheet.Columns().AdjustToContents();

                workbook.SaveAs(filePath);
            }
        }

        public void ExportMeasurementsToExcel(IEnumerable<WellMeasurement> measurements, string filePath)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Замеры");

                // Заголовки
                worksheet.Cell(1, 1).Value = "Дата";
                worksheet.Cell(1, 2).Value = "Скважина";
                worksheet.Cell(1, 3).Value = "Объём (тыс. м³)";
                worksheet.Cell(1, 4).Value = "Давление (атм)";
                worksheet.Cell(1, 5).Value = "Температура (°C)";
                worksheet.Cell(1, 6).Value = "Оператор";

                // Стиль заголовков
                var headerRow = worksheet.Row(1);
                headerRow.Style.Font.Bold = true;
                headerRow.Style.Fill.BackgroundColor = XLColor.LightGreen;

                // Данные
                int row = 2;
                foreach (var measurement in measurements)
                {
                    worksheet.Cell(row, 1).Value = measurement.MeasurementDate.ToString("dd.MM.yyyy HH:mm");
                    worksheet.Cell(row, 2).Value = measurement.Well?.WellNumber ?? "";
                    worksheet.Cell(row, 3).Value = measurement.GasVolume ?? 0;
                    worksheet.Cell(row, 4).Value = measurement.Pressure ?? 0;
                    worksheet.Cell(row, 5).Value = measurement.Temperature ?? 0;
                    worksheet.Cell(row, 6).Value = measurement.OperatorName;
                    row++;
                }

                worksheet.Columns().AdjustToContents();
                workbook.SaveAs(filePath);
            }
        }

        public void ExportMaintenanceToExcel(IEnumerable<Maintenance> maintenances, string filePath)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Обслуживание");

                // Заголовки
                worksheet.Cell(1, 1).Value = "Скважина";
                worksheet.Cell(1, 2).Value = "Тип работ";
                worksheet.Cell(1, 3).Value = "Начало";
                worksheet.Cell(1, 4).Value = "Окончание";
                worksheet.Cell(1, 5).Value = "Описание";
                worksheet.Cell(1, 6).Value = "Ответственный";
                worksheet.Cell(1, 7).Value = "Результат";

                // Стиль заголовков
                var headerRow = worksheet.Row(1);
                headerRow.Style.Font.Bold = true;
                headerRow.Style.Fill.BackgroundColor = XLColor.LightYellow;

                // Данные
                int row = 2;
                foreach (var maintenance in maintenances)
                {
                    worksheet.Cell(row, 1).Value = maintenance.Well?.WellNumber ?? "";
                    worksheet.Cell(row, 2).Value = maintenance.WorkType;
                    worksheet.Cell(row, 3).Value = maintenance.StartDate?.ToString("dd.MM.yyyy") ?? "";
                    worksheet.Cell(row, 4).Value = maintenance.EndDate?.ToString("dd.MM.yyyy") ?? "";
                    worksheet.Cell(row, 5).Value = maintenance.Description;
                    worksheet.Cell(row, 6).Value = maintenance.ResponsiblePerson;
                    worksheet.Cell(row, 7).Value = maintenance.Result;
                    row++;
                }

                worksheet.Columns().AdjustToContents();
                workbook.SaveAs(filePath);
            }
        }

        public void ExportReportToExcel(Dictionary<string, decimal> volumeByWell, decimal totalVolume,
                                        DateTime startDate, DateTime endDate, string filePath)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Отчёт");

                // Заголовок отчёта
                worksheet.Cell(1, 1).Value = "Отчёт по добыче газа";
                worksheet.Cell(1, 1).Style.Font.Bold = true;
                worksheet.Cell(1, 1).Style.Font.FontSize = 16;

                worksheet.Cell(2, 1).Value = $"Период: {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}";

                worksheet.Cell(4, 1).Value = "Скважина";
                worksheet.Cell(4, 2).Value = "Объём добычи (тыс. м³)";

                var headerRow = worksheet.Row(4);
                headerRow.Style.Font.Bold = true;
                headerRow.Style.Fill.BackgroundColor = XLColor.LightBlue;

                int row = 5;
                foreach (var item in volumeByWell)
                {
                    worksheet.Cell(row, 1).Value = item.Key;
                    worksheet.Cell(row, 2).Value = item.Value;
                    row++;
                }

                // Итого
                worksheet.Cell(row + 1, 1).Value = "ИТОГО:";
                worksheet.Cell(row + 1, 1).Style.Font.Bold = true;
                worksheet.Cell(row + 1, 2).Value = totalVolume;
                worksheet.Cell(row + 1, 2).Style.Font.Bold = true;

                worksheet.Columns().AdjustToContents();
                workbook.SaveAs(filePath);
            }
        }
    }
}