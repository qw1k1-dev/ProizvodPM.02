﻿using GazpromModule.Models;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace GazpromModule.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Field> Fields { get; set; }
        public DbSet<Well> Wells { get; set; }
        public DbSet<WellMeasurement> WellMeasurements { get; set; }
        public DbSet<Maintenance> Maintenances { get; set; }
        public DbSet<GasPrice> GasPrices { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Well>()
                .HasMany(w => w.Measurements)
                .WithOne(m => m.Well)
                .HasForeignKey(m => m.WellID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Well>()
                .HasMany(w => w.Maintenances)
                .WithOne(m => m.Well)
                .HasForeignKey(m => m.WellID)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}