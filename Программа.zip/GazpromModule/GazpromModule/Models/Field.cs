﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GazpromModule.Models
{
    [Table("Fields")]
    public class Field
    {
        [Key]
        public int FieldID { get; set; }

        [Required]
        [MaxLength(100)]
        public string FieldName { get; set; }

        [MaxLength(100)]
        public string Region { get; set; }

        public DateTime? DiscoveryDate { get; set; }

        public virtual ICollection<Well> Wells { get; set; }
    }
}