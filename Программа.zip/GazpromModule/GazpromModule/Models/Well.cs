﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GazpromModule.Models
{
    [Table("Wells")]
    public class Well
    {
        [Key]
        public int WellID { get; set; }

        public int FieldID { get; set; }

        [ForeignKey("FieldID")]
        public virtual Field Field { get; set; }

        [Required]
        [MaxLength(50)]
        public string WellNumber { get; set; }

        [MaxLength(50)]
        public string WellType { get; set; }

        public decimal? Depth { get; set; }

        [MaxLength(50)]
        public string Status { get; set; }

        public DateTime? CommissioningDate { get; set; }

        public virtual ICollection<WellMeasurement> Measurements { get; set; }
        public virtual ICollection<Maintenance> Maintenances { get; set; }
    }
}