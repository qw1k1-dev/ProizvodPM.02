﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GazpromModule.Models
{
    [Table("Maintenance")]
    public class Maintenance
    {
        [Key]
        public int MaintenanceID { get; set; }

        public int WellID { get; set; }

        [ForeignKey("WellID")]
        public virtual Well Well { get; set; }

        [Required]
        [MaxLength(100)]
        public string WorkType { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public string Description { get; set; }

        [MaxLength(100)]
        public string ResponsiblePerson { get; set; }

        [MaxLength(255)]
        public string Result { get; set; }
    }
}