﻿using System;
using System.Collections.Generic;

namespace GazpromModule.Models
{
    // Модель для ответа API с ценами на газ
    public class GasPriceApiResponse
    {
        public DateTime Date { get; set; }
        public decimal Price { get; set; }
        public string Currency { get; set; }
        public string Unit { get; set; }
    }

    // Модель для API погоды (для примера)
    public class WeatherApiResponse
    {
        public string Location { get; set; }
        public decimal Temperature { get; set; }
        public string Condition { get; set; }
    }

    // Модель для API курсов валют
    public class CurrencyApiResponse
    {
        public string Base { get; set; }
        public Dictionary<string, decimal> Rates { get; set; }
    }
}