﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GazpromModule.Models
{
    [Table("WellMeasurements")]
    public class WellMeasurement
    {
        [Key]
        public long MeasurementID { get; set; }

        public int WellID { get; set; }

        [ForeignKey("WellID")]
        public virtual Well Well { get; set; }

        [Required]
        public DateTime MeasurementDate { get; set; }

        public decimal? GasVolume { get; set; }

        public decimal? Pressure { get; set; }

        public decimal? Temperature { get; set; }

        [MaxLength(100)]
        public string OperatorName { get; set; }
    }
}