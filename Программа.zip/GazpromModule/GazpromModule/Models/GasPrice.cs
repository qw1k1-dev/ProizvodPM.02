﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GazpromModule.Models
{
    [Table("GasPrices")]
    public class GasPrice
    {
        [Key]
        public int PriceID { get; set; }

        [Required]
        public DateTime PriceDate { get; set; }

        [Required]
        public decimal PricePer1000m3 { get; set; }

        [MaxLength(10)]
        public string Currency { get; set; }
    }
}