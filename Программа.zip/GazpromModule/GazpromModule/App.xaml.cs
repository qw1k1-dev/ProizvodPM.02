﻿using System;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using GazpromModule.Data;
using GazpromModule.Services;
using GazpromModule.ViewModels;
using GazpromModule.Views;

namespace GazpromModule
{
    public partial class App : Application
    {
        private ServiceProvider _serviceProvider;
        private LoginWindow _loginWindow;
        private MainWindow _mainWindow;
        private LoginViewModel _currentLoginViewModel;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            var services = new ServiceCollection();

            // Регистрация DbContext
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer("Server=localhost;Database=GazpromDb;Trusted_Connection=True;TrustServerCertificate=True;"));

            // Регистрация сервисов
            services.AddSingleton<AuthService>();
            services.AddSingleton<DataService>();
            services.AddSingleton<DialogService>();
            services.AddSingleton<ExcelExportService>();

            // Регистрация API сервисов
            services.AddHttpClient<ApiService>(client =>
            {
                client.BaseAddress = new Uri("https://api.example.com/");
                client.Timeout = TimeSpan.FromSeconds(30);
            });
            services.AddSingleton<GasPriceService>();

            // Регистрация ViewModels
            services.AddTransient<LoginViewModel>();
            services.AddTransient<RegisterViewModel>();
            services.AddTransient<AddWellViewModel>();
            services.AddTransient<EditWellViewModel>();
            services.AddTransient<AddMeasurementViewModel>();
            services.AddTransient<EditMeasurementViewModel>();
            services.AddTransient<AddMaintenanceViewModel>();
            services.AddTransient<EditMaintenanceViewModel>();
            services.AddTransient<ApiViewModel>();

            _serviceProvider = services.BuildServiceProvider();

            InitializeDatabase();

            ShowLoginWindow();
        }

        private void ShowLoginWindow()
        {
            _currentLoginViewModel = _serviceProvider.GetRequiredService<LoginViewModel>();
            _loginWindow = new LoginWindow(_currentLoginViewModel);

            _currentLoginViewModel.LoginSuccessful += OnLoginSuccessful;

            _loginWindow.Show();
        }

        private void OnLoginSuccessful(object sender, EventArgs e)
        {
            if (_currentLoginViewModel != null)
            {
                _currentLoginViewModel.LoginSuccessful -= OnLoginSuccessful;
            }

            var currentUser = _currentLoginViewModel?.CurrentUser;

            if (currentUser != null)
            {
                var mainViewModel = new MainViewModel(
                    _serviceProvider.GetRequiredService<DataService>(),
                    _serviceProvider.GetRequiredService<DialogService>(),
                    currentUser,
                    _serviceProvider.GetRequiredService<ApiService>(),
                    _serviceProvider.GetRequiredService<GasPriceService>());

                mainViewModel.LogoutRequested += OnLogoutRequested;

                _mainWindow = new MainWindow(mainViewModel);
                MainWindow = _mainWindow;

                if (_loginWindow != null)
                {
                    _loginWindow.Close();
                    _loginWindow = null;
                }

                _mainWindow.Show();
            }
        }

        private void OnLogoutRequested(object sender, EventArgs e)
        {
            if (_mainWindow != null)
            {
                _mainWindow.Close();
                _mainWindow = null;
            }

            ShowLoginWindow();
        }

        private void InitializeDatabase()
        {
            try
            {
                using (var scope = _serviceProvider.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                    context.Database.EnsureCreated();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации базы данных: {ex.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _serviceProvider?.Dispose();
            base.OnExit(e);
        }
    }
}