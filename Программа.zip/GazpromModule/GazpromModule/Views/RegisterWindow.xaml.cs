﻿using System.Windows;
using System.Windows.Controls;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class RegisterWindow : Window
    {
        private readonly RegisterViewModel _viewModel;

        public RegisterWindow(RegisterViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            _viewModel.RegistrationSuccessful += OnRegistrationSuccessful;

            PasswordBox.PasswordChanged += (s, e) => _viewModel.Password = PasswordBox.Password;
            ConfirmPasswordBox.PasswordChanged += (s, e) => _viewModel.ConfirmPassword = ConfirmPasswordBox.Password;

            // Устанавливаем роль по умолчанию
            RoleComboBox.SelectedIndex = 0;
        }

        private void RoleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RoleComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                _viewModel.Role = selectedItem.Tag?.ToString() ?? selectedItem.Content?.ToString();
            }
        }

        private void OnRegistrationSuccessful(object sender, System.EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        protected override void OnClosed(System.EventArgs e)
        {
            _viewModel.RegistrationSuccessful -= OnRegistrationSuccessful;
            base.OnClosed(e);
        }
    }
}