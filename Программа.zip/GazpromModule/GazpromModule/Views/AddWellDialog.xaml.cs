﻿using System.Windows;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class AddWellDialog : Window
    {
        private readonly AddWellViewModel _viewModel;

        public AddWellDialog(AddWellViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            _viewModel.WellAdded += OnWellAdded;
        }

        private void OnWellAdded(object sender, System.EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        protected override void OnClosed(System.EventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.WellAdded -= OnWellAdded;
            }
            base.OnClosed(e);
        }
    }
}