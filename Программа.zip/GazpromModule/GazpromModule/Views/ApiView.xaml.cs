﻿using System.Windows.Controls;

namespace GazpromModule.Views
{
    public partial class ApiView : UserControl
    {
        public ApiView()
        {
            InitializeComponent();
        }
    }
}