﻿using System.Windows;
using System.Windows.Input;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _viewModel;

        public MainWindow(MainViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;
        }

        private void WellsListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (_viewModel.SelectedWell != null && _viewModel.EditWellCommand.CanExecute(null))
            {
                _viewModel.EditWellCommand.Execute(null);
            }
        }

        private void MeasurementsGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (_viewModel.SelectedMeasurement != null && _viewModel.EditMeasurementCommand.CanExecute(null))
            {
                _viewModel.EditMeasurementCommand.Execute(null);
            }
        }

        private void MaintenancesGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (_viewModel.SelectedMaintenance != null && _viewModel.EditMaintenanceCommand.CanExecute(null))
            {
                _viewModel.EditMaintenanceCommand.Execute(null);
            }
        }
    }
}