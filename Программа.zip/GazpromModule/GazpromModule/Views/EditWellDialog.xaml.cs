﻿using System.Windows;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class EditWellDialog : Window
    {
        private readonly EditWellViewModel _viewModel;

        public EditWellDialog(EditWellViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            _viewModel.WellUpdated += OnWellUpdated;
        }

        private void OnWellUpdated(object sender, System.EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        protected override void OnClosed(System.EventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.WellUpdated -= OnWellUpdated;
            }
            base.OnClosed(e);
        }
    }
}