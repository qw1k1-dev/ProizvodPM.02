﻿using System.ComponentModel;
using System.Windows;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class LoginWindow : Window
    {
        private readonly LoginViewModel _viewModel;

        public LoginWindow(LoginViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            // Привязка пароля
            PasswordBox.PasswordChanged += (s, e) =>
            {
                _viewModel.Password = PasswordBox.Password;
            };
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            // Если пользователь не вошел и закрывает окно - выходим из приложения
            if (_viewModel.CurrentUser == null)
            {
                Application.Current.Shutdown();
            }
        }
    }
}