﻿using System.Windows;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class AddMaintenanceDialog : Window
    {
        private readonly AddMaintenanceViewModel _viewModel;

        public AddMaintenanceDialog(AddMaintenanceViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            _viewModel.MaintenanceAdded += OnMaintenanceAdded;
        }

        private void OnMaintenanceAdded(object sender, System.EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        protected override void OnClosed(System.EventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.MaintenanceAdded -= OnMaintenanceAdded;
            }
            base.OnClosed(e);
        }
    }
}