﻿using System.Windows;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class AddMeasurementDialog : Window
    {
        private readonly AddMeasurementViewModel _viewModel;

        public AddMeasurementDialog(AddMeasurementViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            _viewModel.MeasurementAdded += OnMeasurementAdded;
        }

        private void OnMeasurementAdded(object sender, System.EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        protected override void OnClosed(System.EventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.MeasurementAdded -= OnMeasurementAdded;
            }
            base.OnClosed(e);
        }
    }
}