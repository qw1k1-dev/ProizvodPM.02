﻿using System.Windows;
using GazpromModule.ViewModels;

namespace GazpromModule.Views
{
    public partial class EditMaintenanceDialog : Window
    {
        private readonly EditMaintenanceViewModel _viewModel;

        public EditMaintenanceDialog(EditMaintenanceViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            _viewModel.MaintenanceUpdated += OnMaintenanceUpdated;
        }

        private void OnMaintenanceUpdated(object sender, System.EventArgs e)
        {
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        protected override void OnClosed(System.EventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.MaintenanceUpdated -= OnMaintenanceUpdated;
            }
            base.OnClosed(e);
        }
    }
}